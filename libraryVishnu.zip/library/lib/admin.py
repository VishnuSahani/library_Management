from django.contrib import admin
from .models import bookDetail,gallery

# Register your models here.
admin.site.register(bookDetail)
admin.site.register(gallery)

